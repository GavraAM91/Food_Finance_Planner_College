// use header
#define _HAS_STD_BYTE 0
#define NOMINMAX
#include <windows.h>

#include "FoodPlanningForm.h"
#include "backend/FoodPlanner.h"
#include <iomanip>

// HELPED BY GPT UN UK FUNGSI INI SAJ A
void FoodPlanningForm::clearScreen()
{
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

// method untuk tanggal dan waktu
string getHari(int wday)
{
    switch (wday)
    {
    case 0:
        return "Minggu";
    case 1:
        return "Senin";
    case 2:
        return "Selasa";
    case 3:
        return "Rabu";
    case 4:
        return "Kamis";
    case 5:
        return "Jumat";
    case 6:
        return "Sabtu";
    }
    return "";
}

string getBulan(int bulan)
{
    switch (bulan)
    {
    case 0:
        return "Januari";
    case 1:
        return "Februari";
    case 2:
        return "Maret";
    case 3:
        return "April";
    case 4:
        return "Mei";
    case 5:
        return "Juni";
    case 6:
        return "Juli";
    case 7:
        return "Agustus";
    case 8:
        return "September";
    case 9:
        return "Oktober";
    case 10:
        return "November";
    case 11:
        return "Desember";
    }
    return "";
}

string getDate()
{
    time_t now = time(0);      // waktu sekarang
    tm *ltm = localtime(&now); // konversi ke struktur waktu

    int tanggal = ltm->tm_mday;
    int bulan = ltm->tm_mon; // 0–11
    int tahun = 1900 + ltm->tm_year;
    int hariKe = ltm->tm_wday; // 0–6 (Minggu = 0)

    string hari = getHari(hariKe);
    string bulanStr = getBulan(bulan);

    // format contoh: "3 Desember 2025, Rabu"
    string finalTanggal =
        to_string(tanggal) + " " +
        bulanStr + " " +
        to_string(tahun) + ", " +
        hari;

    return finalTanggal;
}

// Method untuk membuat planner
void FoodPlanningForm::makePlanner()
{
    while (true)
    {
        // deklarasi variabel yang diperlukan
        int id_mahasiswa, metode;
        string namaMahasiswa, jenisMakanan, tipeMakanan, tipeMinuman;
        double total_budget, sisa_uang;

        // variabel untuk keperluan program
        int opsiUser;
        char pilihanUser;

        // memanggil fungsi clear screen untuk membersihkan data
        clearScreen();

        cout << "=============================================" << endl;
        cout << "      FORM PERENCANAAN MAKAN MAHASISWA" << endl;
        cout << "=============================================" << endl;

        // ambil input id mahasiswa
        cout << left << setw(28) << "Masuukkan Id Mahasiswa : ";
        cin >> id_mahasiswa;
        cin.ignore();

        // input nama mahasiswa
        cout << left << setw(28) << "Masukkan nama Mahasiswa : ";
        getline(cin, namaMahasiswa);
        cin.ignore();

        // masukkan total budget
        cout << left << setw(28) << " Masukkan Total Budget : ";
        cin >> total_budget;
        cin.ignore();

        // perencanaan
        cout << left << setw(28) << " Pilih Metode Hemat " << endl;
        cout << "1. Boros " << endl;
        cout << "2. Saving 10% " << endl;
        cout << "3. Saving 20% " << endl;
        cout << "4. Saving 30% " << endl;
        cout << "5. Saving 50% " << endl;
        cout << "Masukkan Pilihan ( 1 - 5 ) : ";
        cin >> opsiUser;

        switch (opsiUser)
        {
        case 1:
            metode = 0;
            break;
        case 2:
            metode = 10;
            break;
        case 3:
            metode = 20;
            break;
        case 4:
            metode = 30;
            break;
        case 5:
            metode = 50;
            break;

        default:
            cout << "Pilihan tidak ada ulangi kembali ! " << endl;
            system("pause");
            break;
        }

        cin.ignore();

        cout << left << setw(28) << "Jenis Makanan" << ": ";
        getline(cin, jenisMakanan);

        cout << left << setw(28) << "Tipe Makanan" << ": ";
        getline(cin, tipeMakanan);

        cout << left << setw(28) << "Tipe Minuman" << ": ";
        getline(cin, tipeMinuman);

        // deklarasi createplanner :
        FoodPlanning planner;
        json result = planner.createPlanner(
            id_mahasiswa,
            namaMahasiswa,
            total_budget,
            metode,
            sisa_uang,
            jenisMakanan,
            tipeMakanan,
            tipeMinuman);

        // response
        cout << " Lihat Response dari response " << endl;

        // membersihkan layar
        clearScreen();

        // HELP BY GPT
        cout << "\n=== RINGKASAN KEUANGAN ===\n";

        // Cek agar tidak error jika key tidak ada
        if (result.contains("rencana_keuangan"))
        {
            auto rk = result["rencana_keuangan"];

            cout << left << setw(25) << "Total Budget" << ": Rp " << rk["total_budget"] << endl;
            cout << left << setw(25) << "Target Saving" << ": " << rk["opsi_saving_dipilih"]
                 << " (Rp " << rk["nominal_disimpan"] << ")" << endl;
            cout << left << setw(25) << "Batas Makan Harian" << ": Rp " << rk["budget_harian_makan"] << endl;
        }

        cout << "\n"; // Spasi

        cout << "=== JADWAL MENU HARIAN ===\n";

        // Header Tabel
        cout << "-----------------------------------------------------------------------------------------\n";
        cout << left << setw(6) << "Hari"
             << left << setw(10) << "Waktu"
             << left << setw(30) << "Menu Makanan"
             << left << setw(15) << "Harga"
             << left << setw(20) << "Kantin" << endl;
        cout << "-----------------------------------------------------------------------------------------\n";

        // Isi Tabel (Looping data prediksi_menu)
        // vector<PrediksiMenu> listMenu = planner.getFoodPlanner(); //

        // 2. CEK APAKAH DATA ADA
        // if (!listMenu.empty())
        // {
        //     // 3. LOOPING MENGGUNAKAN STRUCT
        //     for (const auto &item : listMenu)
        //     {
        //         // Akses menggunakan titik (.) karena ini Struct
        //         cout << left << setw(6) << item.nama_makanan
        //              << left << setw(10) << item.harga
        //              << left << setw(30) << item.nomor_kantin
        //              << left << "Rp " << setw(12) << item.pemilik_kantin
        //              << left << setw(20) << item.id_makanan << endl;
        //     }
        // }
        // else
        // {
        //     cout << "Data menu belum tersedia. Pastikan prediksi berhasil.\n";
        // }
        cout << "-----------------------------------------------------------------------------------------\n";
        cout << " " << endl;
        cout << "Apakah ingin menyimpan hasil ini ? ( Y / T )";
        cin >> pilihanUser;

        if (pilihanUser == 'y' || pilihanUser == 'Y')
        {
            // Ambil data hasil response API
            if (!planner.response.empty())
            {
                planner.getFoodPlanner(planner.response); // isi struct pk & daftarMenu
                planner.savePlanner();                    // simpan ke TXT
                cout << "Planner berhasil disimpan ke DataFoodPlannerMahasiswa.txt! " << endl;
            }
            else
            {
                cout << " Tidak ada data dari server. Tidak bisa disimpan." << endl;
            }
        }
        else if (pilihanUser == 't' || pilihanUser == 'T')
        {
            cout << " Mengulangi Prediksi......" << endl;
            system("pause");
        }
    }
}

string FoodPlanningForm::readPlanner()
{
    ifstream MyFile("DataFoodPlannerMahasiswa.txt");
    if (!MyFile)
        return "File planner tidak ditemukan.\n";

    string line, lastBlock = "";
    bool collecting = false;

    while (getline(MyFile, line))
    {
        // Jika ketemu tanggal → mulai blok baru
        if (line.find("Tanggal :") != string::npos)
        {
            lastBlock = "";
            collecting = true;
        }

        if (collecting)
            lastBlock += line + "\n";

        // blok selesai saat ketemu garis
        if (line.find("---------------------------------------------") != string::npos)
            collecting = false;
    }

    MyFile.close();

    if (lastBlock.empty())
        return "Tidak ada data planner tersimpan.\n";

    return lastBlock;
}

// method untuk melihat pengeluaran harian
string FoodPlanningForm::readDailyExpenses()
{
    ifstream MyFile("DailyExpenses.txt");
    if (!MyFile)
        return "File pengeluaran harian tidak ditemukan.\n";

    string line, lastBlock = "";
    bool collecting = false;

    while (getline(MyFile, line))
    {
        if (line.find("Tanggal :") != string::npos)
        {
            lastBlock = "";
            collecting = true;
        }

        if (collecting)
            lastBlock += line + "\n";

        if (line.find("---------------------------------------------") != string::npos)
            collecting = false;
    }

    MyFile.close();

    if (lastBlock.empty())
        return "Belum ada pengeluaran harian.\n";

    return lastBlock;
}

// method untuk membua pengeluaran harian
string FoodPlanningForm::createDailyExpenses(int jumlahPengeluaran,
                                             double totalUangYangDikeluarkanHariIni)
{
    ofstream file("DailyExpenses.txt", ios::app);

    if (!file)
        return "Gagal membuka file pengeluaran harian!\n";

    // header tanggal
    file << "=============================================\n";
    file << "Tanggal : " << getDate() << "\n";
    file << "Total Pengeluaran Hari Ini : Rp" << totalUangYangDikeluarkanHariIni << "\n";
    file << "Jumlah Item                : " << jumlahPengeluaran << "\n";
    file << "---------------------------------------------\n\n";

    file.close();

    return "Pengeluaran harian berhasil disimpan.\n";
}

// method untuk melihat seluruh planner
string FoodPlanningForm::checkAllPlanner()
{
    ifstream MyFile("DataFoodPlannerMahasiswa.txt");
    if (!MyFile)
        return "File planner tidak ditemukan.\n";

    string line, isi = "";

    while (getline(MyFile, line))
        isi += line + "\n";

    MyFile.close();

    if (isi.empty())
        return "Tidak ada data planner tersimpan.\n";

    return isi;
}