// Deklrasi library yang akan digunakan
#define _HAS_STD_BYTE 0
#define NOMINMAX
#include <windows.h>

#include "FoodPlanner.h"
using json = nlohmann::json;

// method untuk menyimpan pengeluaran haria
void FoodPlanning::dailyExpenses()
{
    // menggunakan variabel wawktu
    time_t timestamp;
    tm *waktu = localtime(&timestamp);

    // open file
    ifstream MyFile("DataFoodPlannerMahasiswa.txt");

    // error handling
    if (!MyFile)
    {
        return;
    }

    // check apakah ada
}

// method untuk check data planner tersimpan berdasarkan tanggal
// TAHAP PENGEMBANGAN
void FoodPlanning::getSavedPlanner()
{
    // check file
    string isiText;

    // buka file
    ifstream MyFile("DataFoodPlannerMahasiswa.txt");

    // cari berdasakrna data tanggal pembuatan

    if (!MyFile)
    {
        return;
    }

    while (getline(MyFile, isiText))
    {

        return;
    }

    // tutup file
    MyFile.close();

    return;
}

// method untuk mengambil data dari json
// void FoodPlanning::getFoodPlanner(string &response)
// {
//     // get data atau respon dari json
//     json dataJSON = Json::parse(response);
//     // string jsonString = dataJSON[0]["output"];

//     // json dataString = json::parse(jsonString);

//     // masukkan ke rencana keuangan
//     auto rk = dataJSON["rencana_keuangan"];

//     pk.total_budget = rk["total_budget"];
//     pk.saving_rate = rk["saving_rate"];
//     pk.uang_disimpan = rk["nominal_disimpan"];
//     pk.budget_harian = rk["budget_harian_makanan"];

//     // digunakan untuk iterasi
//     int i = 0;

//     // masukkan ke planning makanan ( HELPED BY GPT BAGIAN AUTO )
//     for (auto &item : dataJSON["prediksi_menu"])
//     {
//         pm.id_makanan = item["id_makanan"];
//         pm.harga = item["harga"];
//         pm.nama_makanan = item["nama_makanan"];
//         pm.pemilik_kantin = item["pemilik_kantin"];
//         pm.tipe_makanan = item["tipe_makanan"];
//         pm.nomor_kantin = item["nomor_kantin"];
//         i++;
//     }

// }

// HELPED BY LLM ( BECAUSE MY PROGRESS KINDA CRASH ) FOR SHOWING THAT MY PROGRAM JALAN
void FoodPlanning::getFoodPlanner(string &response)
{
    cout << "\n=== RAW RESPONSE ===\n"
         << response << endl;

    // 1. Parse level pertama
    json raw = json::parse(response);
    string innerText = raw["output"];

    // 3. Parse isi string menjadi JSON asli
    json data = json::parse(innerText);

    // 4. Ambil rencana keuangan
    auto rk = data["rencana_keuangan"];

    pk.total_budget = rk["total_budget"].get<double>();
    pk.saving_rate = rk["opsi_saving_dipilih"].get<string>();
    pk.uang_disimpan = rk["nominal_disimpan"].get<double>();
    pk.budget_harian = rk["budget_harian_makan"].get<double>();

    // 5. Ambil prediksi menu (rapi)
    daftarMenu.clear();
    for (auto &item : data["prediksi_menu"])
    {
        PrediksiMenu m;
        m.id_makanan = item["id_makanan"];
        m.nama_makanan = item["nama_makanan"];
        m.nomor_kantin = item["nomor_kantin"];
        m.pemilik_kantin = item["pemilik_kantin"];
        m.harga = item["harga"];
        m.tipe_makanan = item["tipe_makanan"];

        daftarMenu.push_back(m);
    }

    // === OUTPUT RAPI ===
    cout << "\n===== RENCANA KEUANGAN =====\n";
    cout << "Total Budget     : " << pk.total_budget << endl;
    cout << "Saving Rate      : " << pk.saving_rate << endl;
    cout << "Uang Disimpan    : " << pk.uang_disimpan << endl;
    cout << "Budget Harian    : " << pk.budget_harian << endl;

    cout << "\n===== MENU MINGGU INI =====\n";
    for (auto &m : daftarMenu)
    {
        cout << "Nama makanan " << m.nama_makanan
             << " | " << m.tipe_makanan
             << " | Rp " << m.harga
             << " | Kantin " << m.nomor_kantin
             << " (" << m.pemilik_kantin << ")"
             << endl;
    }
}

// method untuk simpan data ke .txt
void FoodPlanning::savePlanner()
{
    // digunakan untuk iterasi
    int i = 0;

    // buka file
    ofstream MyFile("DataFoodPlannerMahasiswa.txt");

    // handler error
    if (!MyFile)
    {
        return;
    }

    // memasukkan data dari struct PrediksiDataKeuangan ke file
    MyFile << "===    PREDIKSI DATA KEUANGAN  ===\n";
    MyFile << "Total Budget : " << pk.total_budget << "\n";
    MyFile << "Saving       : " << pk.saving_rate << "\n";
    MyFile << "Disimpan     : " << pk.uang_disimpan << "\n";
    MyFile << "Harian Makan : " << pk.budget_harian << "\n\n";
    MyFile << "--------------------------------------------------\n";

    // gunakan perulagnan for untuk penyimpanan list makanan
    MyFile << "===    PREDIKSI DATA MAKANAN  ===\n";
    for (auto &dataMenu : daftarMenu)
    {
        i++;
        MyFile << "Nomor : " << i
               << " | " << dataMenu.nama_makanan
               << " | " << dataMenu.nomor_kantin
               << " | " << dataMenu.pemilik_kantin
               << " | " << dataMenu.tipe_makanan
               << " | Rp" << dataMenu.harga << "\n";
    }

    // tutup file
    MyFile.close();
};

// method berisi data untuk membuat planner
json FoodPlanning::createPlanner(int id_mahasiswa, string namaMahasiswa, double total_budget, int metode, double sisa_uang, string jenisMakanan, string tipeMakanan, string tipeMinuman)
{
    json dataJSON;

    // set data untuk json
    dataJSON["id_mahasiswa"] = id_mahasiswa;
    dataJSON["nama_mahasiswa"] = namaMahasiswa;
    dataJSON["total_budget"] = total_budget;
    dataJSON["metode"] = metode;
    dataJSON["sisa_uang"] = sisa_uang;
    dataJSON["tipeMakanan"] = tipeMakanan;
    dataJSON["jenisMakanan"] = jenisMakanan;
    dataJSON["tipeMinuman"] = tipeMinuman;

    // convert json ke string ( tapi struktur tetap json )
    string JsonString = dataJSON.dump();

    bool status = api.postJSON(JsonString, &response); //

    if (!status)
    {
        return false;
    }

    return dataJSON;
}

// method untuk upload pengeluaran harian ke database
// json FoodPlanning

// menangkap request dari curl
size_t FoodPlanning::WriteCallback(void *contents, size_t size, size_t nmemb, void *userp)
{
    ((string *)userp)->append((char *)contents, size * nmemb);
    return size * nmemb;
}
